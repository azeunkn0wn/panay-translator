package com.example.panay_translator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
