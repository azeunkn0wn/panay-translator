package com.example.PanayTranslator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
